import pygame
import random
import os
import time
import sys

pygame.init()

window_width, window_height = 1440, 900
main_window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("blackjack4babies.exe")

green = (0, 128, 0)
black = (0, 0, 0)
blue = (0, 0, 255)
white = (255, 255, 255)

font = pygame.font.SysFont("Comic Sans MS", 24)
button_fonts = pygame.font.SysFont("Comic Sans MS", 30)

card_width, card_height = 140, 196

card_images = {}
card_folder = "cards"
for suit in ['hearts', 'diamonds', 'clubs', 'spades']:
    for value in ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'jack', 'queen', 'king', 'ace']:
        image = pygame.image.load(os.path.join(card_folder, f"{value}_{suit}.png"))
        card_images[f"{value}_{suit}"] = pygame.transform.scale(image, (card_width, card_height))

card_back = pygame.image.load(os.path.join(card_folder, "back_card.png"))
card_back = pygame.transform.scale(card_back, (card_width, card_height))

background = pygame.image.load(os.path.join(card_folder, "blackjackfelt.jpg"))
background = pygame.transform.scale(background, (window_width, window_height))

baby_image = pygame.image.load(os.path.join(card_folder, "baby.png"))
baby_image = pygame.transform.scale(baby_image, (300, 300))
sad_baby = pygame.image.load(os.path.join(card_folder, "sadbaby.png"))
sad_baby = pygame.transform.scale(sad_baby, (400, 400))
fruits_image = pygame.image.load(os.path.join(card_folder, "fruits.png"))
fruits_image = pygame.transform.scale(fruits_image, (450, 225))
casino_image = pygame.image.load(os.path.join(card_folder, "casino.png"))
casino_image = pygame.transform.scale(casino_image, (300, 200))

class Card:
    def __init__(self, suit, value):
        self.suit = suit
        self.value = value
        self.image = card_images[f"{value}_{suit}"]


def create_deck():
    deck = []
    for suit in ['hearts', 'diamonds', 'clubs', 'spades']:
        for value in ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'jack', 'queen', 'king', 'ace']:
            deck.append(Card(suit, value))
    random.shuffle(deck)
    return deck


class Hand:
    def __init__(self):
        self.cards = []

    def add_card(self, card):
        self.cards.append(card)

    def get_value(self, reveal_all=False):
        total = 0
        ace_count = 0
        for i, card in enumerate(self.cards):
            if not reveal_all and i == 1:
                continue
            if card.value in ['jack', 'queen', 'king']:
                total += 10
            elif card.value == 'ace':
                total += 11
                ace_count += 1
            else:
                total += int(card.value)
        while total > 21 and ace_count:
            total -= 10
            ace_count -= 1
        return total


class Button:
    def __init__(self, x, y, width, height, text):
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text

    def draw(self):
        pygame.draw.rect(main_window, blue, self.rect)
        pygame.draw.rect(main_window, black, self.rect, 2)
        text_surface = button_fonts.render(self.text, True, white)
        main_window.blit(text_surface, (
            self.rect.centerx - text_surface.get_width() // 2,
            self.rect.centery - text_surface.get_height() // 2
        ))


def draw_hand(hand, x, y, reveal_all=False):
    for i, card in enumerate(hand.cards):
        if not reveal_all and i == 1:
            main_window.blit(card_back, (x + i * (card_width + 20), y))
        else:
            main_window.blit(card.image, (x + i * (card_width + 20), y))


def draw_all(player_hand, dealer_hand, player_value, dealer_value, reveal_dealer, result_message, game_over_flag):
    """Redraw background, hands, text and baby image. (Calls display.update once.)"""
    main_window.blit(background, (0, 0))
    draw_hand(player_hand, 100, 400, reveal_all=player_hidden_revealed)
    draw_hand(dealer_hand, 100, 100, reveal_all=reveal_dealer)
    player_text = font.render(f"Player: {player_value}", True, white)
    dealer_text = font.render(f"Dealer: {dealer_value}", True, white)
    main_window.blit(player_text, (100, 350))
    main_window.blit(dealer_text, (100, 50))
    if result_message:
        result_text = font.render(result_message, True, white)
        main_window.blit(result_text, (window_width // 2 - 150, int(window_height * 0.75)))
    if not game_over_flag:
        main_window.blit(baby_image, (window_width - 300, 100))
    else:
      
        if result_message in ("You Lose!", "Dealer has Blackjack! You Lose!", "Player busts. Game over."):
            main_window.blit(sad_baby, (window_width - 400, 100))
        else:
            main_window.blit(baby_image, (window_width - 300, 100))
    baby_x, baby_y = window_width - 400, 100          
    casino_x = baby_x - 200                           
    casino_y = baby_y - 50                            
    main_window.blit(casino_image, (casino_x, casino_y))
    fruit_x = 25                                   
    fruit_y = window_height - fruits_image.get_height() - 25
    main_window.blit(fruits_image, (fruit_x, fruit_y))


# ─────────────────────────────────────────────────────────────────────
# globals that need to survive between rounds
player_hidden_revealed = False
show_play_again        = False
game_over_time         = 0
play_again_button      = None
# ─────────────────────────────────────────────────────────────────────


def main():
    global player_hidden_revealed, show_play_again, game_over_time, play_again_button

    # ── reset per-round globals ──────────────────────────────────────
    player_hidden_revealed = False
    show_play_again        = False
    game_over_time         = 0
    # ─────────────────────────────────────────────────────────────────

    deck          = create_deck()
    player_hand   = Hand()
    dealer_hand   = Hand()
    for _ in range(2):
        player_hand.add_card(deck.pop())
        dealer_hand.add_card(deck.pop())

    hit_button    = Button(1100, 750, 150, 100, "Hit")
    stand_button  = Button(1100, 600, 150, 100, "Stand")
    play_again_button = Button(window_width // 2 - 100,
                               window_height // 2 - 40,
                               200, 80, "Play Again")

    # state flags
    dealer_turn          = False
    reveal_dealer_cards  = False
    game_over            = False
    result_message       = ""
    next_dealer_draw     = 0
    dealer_turn_active   = False

    clock   = pygame.time.Clock()
    running = True
    while running:
        clock.tick(30)
        now = pygame.time.get_ticks()

        # ── INPUT ────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = event.pos

                # 1. Play-Again click (has top priority)
                if show_play_again and play_again_button.rect.collidepoint(pos):
                    return                      # ← restart a brand-new round

                # 2. Normal in-game clicks
                if not game_over and not dealer_turn_active:
                    if hit_button.rect.collidepoint(pos):
                        if not player_hidden_revealed and len(player_hand.cards) == 2:
                            player_hidden_revealed = True
                        else:
                            player_hand.add_card(deck.pop())
                    elif stand_button.rect.collidepoint(pos):
                        dealer_turn         = True
                        reveal_dealer_cards = True
                        next_dealer_draw    = now + 1000
        # ─────────────────────────────────────────────────────────────

        # hand values
        player_value = player_hand.get_value(reveal_all=player_hidden_revealed)
        dealer_value = dealer_hand.get_value(reveal_all=reveal_dealer_cards)

        # ── CHECK PLAYER BUST / BLACKJACK ────────────────────────────
        if not game_over:
            if player_value > 21:
                result_message = "Player busts. Game over."
                game_over      = True
                game_over_time = now
            elif player_value == 21:
                result_message = "Blackjack! You Win!"
                game_over      = True
                game_over_time = now
        # ─────────────────────────────────────────────────────────────

        # ── DEALER TURN (non-blocking) ───────────────────────────────
        if dealer_turn and not game_over:
            dealer_turn_active = True
            if now >= next_dealer_draw:
                dealer_value = dealer_hand.get_value(reveal_all=True)
                if len(dealer_hand.cards) == 2 and dealer_value == 21:
                    result_message = "Dealer has Blackjack! You Lose!"
                    game_over      = True
                    game_over_time = now
                    dealer_turn_active = False
                elif dealer_value < 17:
                    dealer_hand.add_card(deck.pop())
                    next_dealer_draw = now + 1000
                else:
                    # compare hands
                    if dealer_value > 21:
                        result_message = "Dealer Busts! You Win!"
                    elif dealer_value == player_value:
                        result_message = "It is a tie. Push."
                    elif player_value > dealer_value:
                        result_message = "You Win!"
                    else:
                        result_message = "You Lose!"
                    game_over      = True
                    game_over_time = now
                    dealer_turn_active = False
        # ─────────────────────────────────────────────────────────────

        # ── SHOW PLAY-AGAIN BUTTON AFTER 2 S ─────────────────────────
        if game_over and not show_play_again and now - game_over_time >= 2000:
            show_play_again = True
        # ─────────────────────────────────────────────────────────────

        # ── DRAW EVERYTHING ──────────────────────────────────────────
        draw_all(player_hand, dealer_hand,
                 player_value, dealer_value,
                 reveal_dealer_cards, result_message, game_over)

        if not game_over and not dealer_turn_active:
            hit_button.draw()
            stand_button.draw()

        if show_play_again:
            play_again_button.draw()

        pygame.display.update()
        # ─────────────────────────────────────────────────────────────


if __name__ == "__main__":
    while True:
        main()